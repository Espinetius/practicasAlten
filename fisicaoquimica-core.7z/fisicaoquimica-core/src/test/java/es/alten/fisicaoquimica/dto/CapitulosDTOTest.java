package es.alten.fisicaoquimica.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CapitulosDTOTest {

	@Test
	public void testSettersAndGetters() {
		Long numCapitulo = 1L;
		Long temporada = 2L;
		String resumen = "Resumen del capítulo";
		Long temCap = 3L;

		CapitulosDTO capitulosDTO = new CapitulosDTO();
		capitulosDTO.setNumCapitulo(numCapitulo);
		capitulosDTO.setTemporada(temporada);
		capitulosDTO.setResumen(resumen);
		capitulosDTO.setTemCap(temCap);

		assertEquals(numCapitulo, capitulosDTO.getNumCapitulo());
		assertEquals(temporada, capitulosDTO.getTemporada());
		assertEquals(resumen, capitulosDTO.getResumen());
		assertEquals(temCap, capitulosDTO.getTemCap());
	}
}
