package es.alten.fisicaoquimica.bo.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import es.alten.fisicaoquimica.bo.CharacterBO;
import es.alten.fisicaoquimica.dao.CharacterRepository;
import es.alten.fisicaoquimica.domain.Characters;
import es.alten.fisicaoquimica.dto.CharacterDTO;

class CharacterBOImplTest {

	@Mock
	private CharacterRepository charrepo;

	@Mock
	private CharacterBO charBO;

	@InjectMocks
	private CharacterBOImpl characterBO;

	private Characters character = new Characters();
	private CharacterDTO result = new CharacterDTO();
	private CharacterDTO compare = new CharacterDTO();

	@BeforeEach
	void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testFindByNomPersonaje() {
		String nomPersonaje = "Clara";
		Mockito.when(charrepo.findByNomPersonaje(nomPersonaje)).thenReturn(character);
		Mockito.when(charBO.findByNomPersonaje(nomPersonaje)).thenReturn(result);
		compare.loadFromDomain(character);
		assertNotNull(result);
		assertEquals(compare, result);
	}

	@Test
	void testFindByNomPersonaje_Empty() {
		Mockito.when(charrepo.findByNomPersonaje(new String())).thenReturn(character);
		Mockito.when(charBO.findByNomPersonaje(new String())).thenReturn(result);
		compare.loadFromDomain(character);
		assertNotNull(result);
		assertEquals(compare, result);
	}

	@Test
	void testFindByNomPersonaje_NULL() {
		Mockito.when(charrepo.findByNomPersonaje(Mockito.anyString())).thenReturn(character);
		Mockito.when(charBO.findByNomPersonaje(Mockito.anyString())).thenReturn(result);
		compare.loadFromDomain(character);
		assertEquals(compare, result);
	}

	@Test
	void testFindByNombre() {
		String nombre = "Nuria";
		Mockito.when(charrepo.findByNombre(nombre)).thenReturn(character);
		Mockito.when(charBO.findByNombre(nombre)).thenReturn(result);
		compare.loadFromDomain(character);
		assertNotNull(result);
		assertEquals(compare, result);
	}
}
