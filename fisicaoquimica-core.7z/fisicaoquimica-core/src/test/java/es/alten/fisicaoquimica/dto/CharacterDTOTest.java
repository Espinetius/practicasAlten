package es.alten.fisicaoquimica.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import es.alten.fisicaoquimica.domain.Capitulos;

@SpringBootTest
public class CharacterDTOTest {

	@Test
	public void testSettersAndGetters() {
		String nombre = "Juan";
		String apellido = "Palomo";
		String nomPersonaje = "Paco";
		String apePersonaje = "Ruiz";

		List<Capitulos> temporadas = new ArrayList<>();
		Capitulos temporada1 = new Capitulos();
		temporada1.setNumCapitulo(1L);
		temporada1.setTemporada(1L);
		temporada1.setResumen("Resumen del capítulo 1");
		temporadas.add(temporada1);

		CharacterDTO characterDTO = new CharacterDTO();
		characterDTO.setNombre(nombre);
		characterDTO.setApellido(apellido);
		characterDTO.setNomPersonaje(nomPersonaje);
		characterDTO.setApePersonaje(apePersonaje);
		characterDTO.setTemporadas(temporadas);

		assertEquals(nombre, characterDTO.getNombre());
		assertEquals(apellido, characterDTO.getApellido());
		assertEquals(nomPersonaje, characterDTO.getNomPersonaje());
		assertEquals(apePersonaje, characterDTO.getApePersonaje());
		assertEquals(temporadas, characterDTO.getTemporadas());
	}
}
