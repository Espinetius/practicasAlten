package es.alten.fisicaoquimica.bo.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import es.alten.fisicaoquimica.dao.CapitulosRepository;
import es.alten.fisicaoquimica.domain.Capitulos;
import es.alten.fisicaoquimica.dto.CapitulosDTO;

class CapitulosBOImplTest {

	@Mock
	CapitulosRepository caprepo;

	@InjectMocks
	private CapitulosBOImpl capitulosBO;

	@BeforeEach
	void init() {
		MockitoAnnotations.initMocks(this);
	}

	private List<Capitulos> capitulosList = new ArrayList<Capitulos>();
	private List<CapitulosDTO> result;

	@Test
	void testFindByTemporada() {
		Long temporada = 1L;
		Capitulos capitulo1 = new Capitulos();
		Capitulos capitulo2 = new Capitulos();
		capitulosList.add(capitulo1);
		capitulosList.add(capitulo2);
		Mockito.when(caprepo.findByTemporada(temporada)).thenReturn(capitulosList);
		result = capitulosBO.findByTemporada(temporada);
		assertNotNull(result);
		assertEquals(2, result.size());
	}

	@Test
	void testFindByTemporada_NULL() {
		Long temporada = null;
		Capitulos capitulo1 = new Capitulos();
		Capitulos capitulo2 = new Capitulos();
		capitulosList.add(capitulo1);
		capitulosList.add(capitulo2);
		Mockito.when(caprepo.findByTemporada(temporada)).thenReturn(capitulosList);
		result = capitulosBO.findByTemporada(temporada);
		assertEquals(2, result.size());
	}

	@Test
	void testFindByNumCapitulo() {
		Long numCapitulo = 1L;
		Capitulos capitulo1 = new Capitulos();
		Capitulos capitulo2 = new Capitulos();
		capitulosList.add(capitulo1);
		capitulosList.add(capitulo2);
		Mockito.when(caprepo.findByNumCapitulo(numCapitulo)).thenReturn(capitulosList);
		result = capitulosBO.findByNumCapitulo(numCapitulo);
		assertNotNull(result);
		assertEquals(2, result.size());
	}

	@Test
	void testFindByTemporadaAndNumCapitulo() {
		Long temporada = 1L;
		Long numCapitulo = 1L;
		Capitulos capitulo1 = new Capitulos();
		Capitulos capitulo2 = new Capitulos();
		capitulosList.add(capitulo1);
		capitulosList.add(capitulo2);
		Mockito.when(caprepo.findByTemporadaAndNumCapitulo(temporada, numCapitulo)).thenReturn(capitulosList);
		result = capitulosBO.findByTemporadaAndNumCapitulo(temporada, numCapitulo);
		assertNotNull(result);
		assertEquals(2, result.size());
	}
}
