package es.alten.fisicaoquimica.dto;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.alten.fisicaoquimica.domain.Capitulos;
import es.alten.fisicaoquimica.domain.Characters;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value = "CharacterDTO", description = "Data transfer object: character")
@Data
@EqualsAndHashCode(callSuper = false)
@SuppressWarnings({ "unused" })
public class CharacterDTO extends ElvisBaseDTO<Characters> {
	private static final long serialVersionUID = 883832912345648321L;
	private static final Logger LOG = LoggerFactory.getLogger(CharacterDTO.class);
	@NotNull
	private String nombre;
	@NotNull
	private String apellido;
	@NotNull
	private String nomPersonaje;

	private String apePersonaje;

	private List<Capitulos> temporadas;
}
