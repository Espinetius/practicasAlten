package es.alten.fisicaoquimica.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;

import es.alten.fisicaoquimica.domain.Characters;
import es.alten.fisicaoquimica.domain.QCharacters;

/**
 * Repository interface for {@link Characters} instances. The interface is used to declare so called query methods, methods to retrieve a single entities or collections of them.
 * 
 * @author david.espinosa
 *
 */
public interface CharacterRepository
		extends ElvisBaseRepository<Characters, Long, QCharacters>, JpaSpecificationExecutor<Characters>, QuerydslPredicateExecutor<Characters>, QuerydslBinderCustomizer<QCharacters> {

	Characters findByNomPersonaje(String nomPersonaje);

	Characters findByNombre(String nombre);
}
