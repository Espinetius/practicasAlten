package es.alten.fisicaoquimica.utils;

import java.io.Serializable;

@SuppressWarnings("unused")
public class Utils implements Serializable {}
