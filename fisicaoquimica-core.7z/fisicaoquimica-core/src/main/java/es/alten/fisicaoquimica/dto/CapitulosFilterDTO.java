package es.alten.fisicaoquimica.dto;

import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import es.alten.fisicaoquimica.domain.Capitulos;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * DTO to store capitulos filtering information
 * 
 * @author david.espinosa
 *
 */
@SuppressWarnings({ "UnusedDeclaration" })
@ApiModel(value = "CapitulosFilterDTO", description = "Capitulos filter")
@EqualsAndHashCode(callSuper = true)
@Data
public class CapitulosFilterDTO extends BaseFilterDTO<Capitulos> {
	/** serialVersionUID for object serialization **/
	private static final long serialVersionUID = 1L;

	private Long temporada;

	@Override
	public Specification<Capitulos> obtainFilterSpecification() {
		return (root, query, cb) -> {
			Predicate predicate = cb.and();
			if (StringUtils.isNotBlank(this.temporada.toString())) {
				predicate = cb.and(predicate, cb.like(root.get("temporada"), "%" + this.temporada + "%"));
			}
			return predicate;
		};
	}

}
