package es.alten.fisicaoquimica.bo.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import es.alten.fisicaoquimica.bo.CapitulosBO;
import es.alten.fisicaoquimica.dao.CapitulosRepository;
import es.alten.fisicaoquimica.domain.Capitulos;
import es.alten.fisicaoquimica.domain.QCapitulos;
import es.alten.fisicaoquimica.dto.CapitulosDTO;
import es.alten.fisicaoquimica.dto.CapitulosFilterDTO;
import es.alten.fisicaoquimica.utils.ListMapper;

/**
 * Implements interface {@link CapitulosBO}
 * 
 * @author david.espinosa
 *
 */
@Service
@Transactional
public class CapitulosBOImpl extends ElvisGenericCRUDServiceImpl<Capitulos, Long, QCapitulos, CapitulosFilterDTO, CapitulosRepository> implements CapitulosBO {

	private static final long serialVersionUID = -831996259972639743L;

	@Autowired
	private transient CapitulosRepository caprepo;

	@Override
	public List<CapitulosDTO> findByTemporada(Long temporada) {
		List<Capitulos> list = caprepo.findByTemporada(temporada);
		List<CapitulosDTO> tempDTO = new ArrayList<>();
		try {
			tempDTO = ListMapper.map(list, CapitulosDTO.class);
		} catch (IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e) {
			e.printStackTrace();
		}
		return tempDTO;
	}

	@Override
	public List<CapitulosDTO> findByNumCapitulo(Long numCapitulo) {

		List<Capitulos> list = caprepo.findByNumCapitulo(numCapitulo);
		List<CapitulosDTO> capDTO = new ArrayList<>();
		try {
			capDTO = ListMapper.map(list, CapitulosDTO.class);
		} catch (IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e) {
			e.printStackTrace();
		}
		return capDTO;
	}

	@Override
	public List<CapitulosDTO> findByTemporadaAndNumCapitulo(Long temporada, Long numCapitulo) {

		List<Capitulos> list = caprepo.findByTemporadaAndNumCapitulo(temporada, numCapitulo);
		List<CapitulosDTO> cap = new ArrayList<>();

		if (list != null && !list.isEmpty()) {
			try {
				cap = ListMapper.map(list, CapitulosDTO.class);
			} catch (IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e) {
				e.printStackTrace();
			}
		}

		return cap;
	}

}
