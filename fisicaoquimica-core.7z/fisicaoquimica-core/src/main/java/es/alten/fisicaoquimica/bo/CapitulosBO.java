package es.alten.fisicaoquimica.bo;

import java.util.List;

import es.alten.fisicaoquimica.domain.Capitulos;
import es.alten.fisicaoquimica.domain.QCapitulos;
import es.alten.fisicaoquimica.dto.CapitulosDTO;
import es.alten.fisicaoquimica.dto.CapitulosFilterDTO;

/**
 * Define services to work with Capitulos
 * 
 * @author david.espinosa
 *
 */
public interface CapitulosBO extends GenericCRUDService<Capitulos, Long, QCapitulos, CapitulosFilterDTO> {

	public List<CapitulosDTO> findByTemporada(Long temporada);

	public List<CapitulosDTO> findByNumCapitulo(Long numCapitulo);

	public List<CapitulosDTO> findByTemporadaAndNumCapitulo(Long temporada, Long numCapitulo);
}
