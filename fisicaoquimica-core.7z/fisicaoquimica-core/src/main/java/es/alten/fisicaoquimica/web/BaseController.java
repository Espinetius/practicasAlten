package es.alten.fisicaoquimica.web;

import java.io.Serializable;

/**
 * Define general control logic to serve requests.
 *
 * @author jlosorno
 */
public interface BaseController extends Serializable {}
