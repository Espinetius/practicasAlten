package es.alten.fisicaoquimica.dto;

import javax.persistence.criteria.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import es.alten.fisicaoquimica.domain.Characters;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** DTO to store characters filtering information **/

@ApiModel(value = "CharacterFilterDTO", description = "Characters filter")
@EqualsAndHashCode(callSuper = true)
@Data
public class CharacterFilterDTO extends BaseFilterDTO<Characters> {
	/** serialVersionUID for object serialization **/
	private static final long serialVersionUID = 1L;

	private String nomCharacter;

	private String nombre;

	@Override
	public Specification<Characters> obtainFilterSpecification() {
		return (root, query, cb) -> {
			Predicate predicate = cb.and();
			if (StringUtils.isNotBlank(this.nomCharacter)) {
				predicate = cb.and(predicate, cb.like(root.get("nomCharacter"), "%" + this.nomCharacter.toLowerCase() + "%"));
			} else if (StringUtils.isNotBlank(nombre)) {
				predicate = cb.and(predicate, cb.like(root.get("nombre"), "%" + this.nombre.toLowerCase() + "%"));
			}
			return predicate;
		};
	}

}
