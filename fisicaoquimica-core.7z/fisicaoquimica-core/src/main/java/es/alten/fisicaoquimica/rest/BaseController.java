package es.alten.fisicaoquimica.rest;

import java.io.Serializable;

/**
 * Define general control logic to serve REST HTTP requests.
 *
 * @author delivery
 */
public interface BaseController extends Serializable {}
