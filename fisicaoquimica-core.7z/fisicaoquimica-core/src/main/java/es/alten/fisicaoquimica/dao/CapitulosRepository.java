package es.alten.fisicaoquimica.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;

import es.alten.fisicaoquimica.domain.Capitulos;
import es.alten.fisicaoquimica.domain.QCapitulos;

/**
 * Repository interface for {@link Capitulos} instances. The interface is used to declare so called query methods, methods to retrieve a single entities or collections of them.
 * 
 * @author david.espinosa
 *
 */

public interface CapitulosRepository
		extends ElvisBaseRepository<Capitulos, Long, QCapitulos>, JpaSpecificationExecutor<Capitulos>, QuerydslPredicateExecutor<Capitulos>, QuerydslBinderCustomizer<QCapitulos> {

	List<Capitulos> findByTemporada(Long temporada);

	List<Capitulos> findByNumCapitulo(Long numCapitulo);

	List<Capitulos> findByTemporadaAndNumCapitulo(Long temporada, Long numCapitulo);
}
