package es.alten.fisicaoquimica.bo.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.alten.fisicaoquimica.bo.CharacterBO;
import es.alten.fisicaoquimica.dao.CharacterRepository;
import es.alten.fisicaoquimica.domain.Characters;
import es.alten.fisicaoquimica.domain.QCharacters;
import es.alten.fisicaoquimica.dto.CharacterDTO;
import es.alten.fisicaoquimica.dto.CharacterFilterDTO;

/**
 * Implements interface {@link CharacterBO}
 * 
 * @author david.espinosa
 * 
 * @noInspection unused
 */
@Service
@Transactional
public class CharacterBOImpl extends ElvisGenericCRUDServiceImpl<Characters, Long, QCharacters, CharacterFilterDTO, CharacterRepository> implements CharacterBO {

	private static final long serialVersionUID = 4558027052312032450L;

	@Autowired
	private transient CharacterRepository charrepo;

	@Override
	public CharacterDTO findByNomPersonaje(String nomPersonaje) {
		Characters character = charrepo.findByNomPersonaje(nomPersonaje);
		CharacterDTO charDTO = new CharacterDTO();
		charDTO.loadFromDomain(character);
		return charDTO;
	}

	@Override
	public CharacterDTO findByNombre(String nombre) {
		Characters character = charrepo.findByNombre(nombre);
		CharacterDTO charDTO = new CharacterDTO();
		charDTO.loadFromDomain(character);
		return charDTO;
	}

}
