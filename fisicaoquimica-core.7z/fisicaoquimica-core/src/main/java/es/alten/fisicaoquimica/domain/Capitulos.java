package es.alten.fisicaoquimica.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@XmlRootElement
@EqualsAndHashCode(callSuper = true)
@Data
@Table(name = "capitulos")
public class Capitulos extends ElvisEntity {
	private static final long serialVersionUID = -8627569243859503763L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Long id;
	@Column(name = "num_capitulo", nullable = false)
	private Long numCapitulo;
	@ManyToMany(mappedBy = "temporadas")
	private List<Characters> caracters;
	@Column(name = "temporada", nullable = false)
	private Long temporada;
	@Column(name = "resumen", nullable = false)
	private String resumen;

}
