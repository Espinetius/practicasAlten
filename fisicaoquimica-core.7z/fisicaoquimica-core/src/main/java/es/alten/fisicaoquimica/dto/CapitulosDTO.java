package es.alten.fisicaoquimica.dto;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.alten.fisicaoquimica.domain.Capitulos;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value = "CapitulosDTO", description = "Data transfer object: capitulos")
@Data
@EqualsAndHashCode(callSuper = true)
@SuppressWarnings({ "unused" })
public class CapitulosDTO extends ElvisBaseDTO<Capitulos> {
	private static final long serialVersionUID = 883832912345648321L;
	private static final Logger LOG = LoggerFactory.getLogger(CapitulosDTO.class);

	@NotNull
	private Long numCapitulo;
	@NotNull
	private Long temporada;
	@NotNull
	private String resumen;

	private Long temCap;
}
