package es.alten.fisicaoquimica.bo;

import es.alten.fisicaoquimica.domain.Characters;
import es.alten.fisicaoquimica.domain.QCharacters;
import es.alten.fisicaoquimica.dto.CharacterDTO;
import es.alten.fisicaoquimica.dto.CharacterFilterDTO;

public interface CharacterBO extends GenericCRUDService<Characters, Long, QCharacters, CharacterFilterDTO> {
	public CharacterDTO findByNomPersonaje(String nomPersonaje);

	public CharacterDTO findByNombre(String nombre);
}
