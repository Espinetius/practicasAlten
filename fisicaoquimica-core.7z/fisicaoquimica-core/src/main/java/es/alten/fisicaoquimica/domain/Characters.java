package es.alten.fisicaoquimica.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;
import lombok.EqualsAndHashCode;
import net.minidev.json.annotate.JsonIgnore;

/** Entity stores information about the characters **/
@Entity
@XmlRootElement
@EqualsAndHashCode(callSuper = true)
@Data
@Table(name = "characters")
public class Characters extends ElvisEntity {

	private static final long serialVersionUID = -8627569243859503763L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Long id;
	@Column(name = "nombre", nullable = false)
	private String nombre;
	@Column(name = "apellido", nullable = false)
	private String apellido;
	@Column(name = "nom_personaje", nullable = false)
	private String nomPersonaje;
	@Column(name = "ape_personaje")
	private String apePersonaje;

	@JsonIgnore
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "characters_temporadas", joinColumns = @JoinColumn(name = "id_personaje", nullable = false), inverseJoinColumns = @JoinColumn(name = "temporadas", nullable = false))
	private List<Capitulos> temporadas;
}
